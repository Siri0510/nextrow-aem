$(document).ready(function(){
	$('.menu').accordion();
});
